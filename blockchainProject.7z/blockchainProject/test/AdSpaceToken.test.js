const { expect } = require('chai');
const { BN, expectEvent, expectRevert, constants } = require('@openzeppelin/test-helpers');
const AdSpaceToken = artifacts.require('AdSpaceToken');
const ERC20Mock = artifacts.require("./mocks/ERC20Mock.sol");

contract("AdSpaceToken", function (accounts) {
  let adSpaceToken, paymentToken;
  const [deployer, user1, user2] = accounts;

  beforeEach(async function () {
    // Deploy the ERC20Mock token for testing
    paymentToken = await ERC20Mock.new("Test Token", "TST", deployer, 100000000);
    // Deploy the AdSpaceToken contract with the paymentToken address
    adSpaceToken = await AdSpaceToken.new(paymentToken.address);
  });

  // Write your tests here

  it('should create an ad space', async function () {
    const uri = 'https://example.com/ad-space-uri';
    const price = new BN('1000000000000000000'); // 1 token with 18 decimals

    const { receipt } = await adSpaceToken.createAdSpace(uri, price, { from: deployer });
    expectEvent(receipt, 'Transfer', { from: constants.ZERO_ADDRESS, to: deployer, tokenId: new BN('0') });

    const adSpace = await adSpaceToken.adSpaces(0);
    expect(adSpace.tokenId).to.be.bignumber.equal(new BN('0'));
    expect(adSpace.uri).to.equal(uri);
    expect(adSpace.price).to.be.bignumber.equal(price);
  });

  it('should buy an ad space', async function () {
    const uri = 'https://example.com/ad-space-uri';
    const price = new BN('1000000000000000000'); // 1 token with 18 decimals

    await adSpaceToken.createAdSpace(uri, price, { from: deployer });
    await paymentToken.transfer(user1, price.mul(new BN('2')), { from: deployer });
    await paymentToken.approve(adSpaceToken.address, price, { from: user1 });

    const { receipt } = await adSpaceToken.buyAdSpace(0, { from: user1 });
    expectEvent(receipt, 'AdSpacePurchased', { tokenId: new BN('0'), buyer: user1 });
    expectEvent(receipt, 'Transfer', { from: deployer, to: user1, tokenId: new BN('0') });

    const adSpaceOwner = await adSpaceToken.ownerOf(0);
    expect(adSpaceOwner).to.equal(user1);
});

});
